#ifndef __worker__
#define __worker__

#include "unit.h"

typedef struct Worker {
    int id;
} Worker;

void unit_act<Unit.worker *unit>();

#endif // __worker__
