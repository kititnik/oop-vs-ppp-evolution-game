#ifndef __unit__
#define __unit__

typedef struct Worker Worker;
typedef struct Warrior Warrior;

typedef struct Unit {
    int id;
} <> Unit;

void unit_act<Unit *unit>();

Unit + <worker: Worker*;>;
Unit + <warrior: Warrior*;>;

#endif // __unit__
