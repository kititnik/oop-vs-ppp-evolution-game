#ifndef __warrior__
#define __warrior__

#include "unit.h"

typedef struct Warrior {
    int id;
} Warrior;

void unit_act<Unit.warrior *unit>();

#endif // __warrior__
